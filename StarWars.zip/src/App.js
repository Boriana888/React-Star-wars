import { useState } from "react";
import "./App.css";
import Hero from "./components/Hero/Hero";
import Home from "./components/Home/Home";
import "./components/Home/Home.css";
import Vehicle from "./components/Vehicle/Vehicle";

function App() {
  // Sample list of heroes with IDs
  const heroes = [
    { id: 1, name: "Luke" },
    { id: 2, name: "C-3PO" },
    { id: 3, name: "R2-D2" },
  ];

  // State to keep track of the selected hero ID
  const [selectedHeroId, setSelectedHeroId] = useState(null);

  // Handler for when the hero selection changes
  const handleHeroSelect = (event) => {
    const selectedId = parseInt(event.target.value);
    setSelectedHeroId(selectedId);
  };

  return (
    <div className="container">
      <h1>Hero Selection:</h1>
      <select onChange={handleHeroSelect} value={selectedHeroId || ""}>
        <option value="">Select a hero</option>
        {heroes.map((hero) => (
          <option key={hero.id} value={hero.id}>
            {hero.name}
          </option>
        ))}
      </select>
      {selectedHeroId && <Hero heroId={selectedHeroId} />}{" "}
      {/* Render MyComponent with the selected hero ID */}
      <Home></Home>
      <Vehicle></Vehicle>
    </div>
  );
}

export default App;
